from flask import Flask,jsonify
app=Flask(__name__)
@app.get('/api/models')
def models():
    return jsonify([{'id':1,'name':'Tiggo 8 Pro'}])
app.run(debug=True)
